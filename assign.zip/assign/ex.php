<style>
	*{
	padding: 0px;
	margin: 0px;
}
.nav{
	width: 100%;
	height: 100px;
	background-color: black;
}
.nav ul{
	list-style: none;
	text-align: center;
}
.nav ul li{
display: inline-flex;
width: 180px;
font-size: 45px;
margin-top: 20px;
}
.nav ul li a{
	color: white;
	text-decoration: none;
}
.body{
	width: 100%;
	height: 400px;

}
.footer{
	background:red;
	color: white;
	width: 100%;
	height: 150px;
}
.footer p{
	font-size: 40px;
	text-align: center;
}

.body img{
	width: 100%;
	height: 100%;
	
}


</style>