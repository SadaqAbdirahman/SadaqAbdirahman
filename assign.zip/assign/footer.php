<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<?php require("ex.php"); ?>
</head>
<body>
  <div class="footer">
    <p>Copyright &copy; 2020-2023 <a href="#">Sadaq</a>.</p>
  </div>
</body>
</html>