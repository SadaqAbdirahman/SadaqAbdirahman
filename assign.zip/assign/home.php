<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<?php require("ex.php"); ?>
</head>
<body>
	
<div class="nav">
	<ul>
		<li><a href="">Home</a></li>
		<li><a href="">Service</a></li>
		<li><a href="">About Us</a></li>
	</ul>
</div>

</body>
</html>