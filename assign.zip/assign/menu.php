<?php 
require("home.php");
require("image.php");
require("footer.php");
?>